package br.edu.ifsc.produto;

public class Produto {
	private int id;
	private String nome;
	private int quantdade;
	private double preco;
	private int taxaLucro;
	
	public Produto () {
		
	}
	
	//ALT + SHIT + S > Generate constructor using fields
	public Produto(int id, String nome, int quantdade, double preco, int taxaLucro) {
		super();
		this.id = id;
		this.nome = nome;
		this.quantdade = quantdade;
		this.preco = preco;
		this.taxaLucro = taxaLucro;
	}
	
	//ALT + SHIFT + S > Generate Getters ans Setters
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public int getQuantdade() {
		return quantdade;
	}
	public void setQuantdade(int quantdade) {
		this.quantdade = quantdade;
	}
	public double getPreco() {
		return preco;
	}
	public void setPreco(double preco) {
		this.preco = preco;
	}
	public int getTaxaLucro() {
		return taxaLucro;
	}
	public void setTaxaLucro(int taxaLucro) {
		this.taxaLucro = taxaLucro;
	}
	
	//calcular preço
	public double calcularPrecoVenda() {
		return preco + (preco * taxaLucro / 100);
	}
	
}
